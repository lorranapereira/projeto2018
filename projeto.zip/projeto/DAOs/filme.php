<?php 

class FilmeDAO {
    private function CriaConexao()
    {
        $scon = "port=5432 host=localhost dbname=bdfilmes
        user=postgres ";
        $con = pg_connect($scon);
        if(!$con){
        echo "conexão com BD falhou!";
        pg_close($con);
        }
        return $con;
    }
    public function inserir($filme)
    {                
        $conn = $this->CriaConexao();             
        $sql = 'INSERT INTO filme (titulo,classif_ind,sinopse,data_lancamento,genero,fk_categoria_id) VALUES ($1,$2,$3,$4,$5,$6) RETURNING ID';
        var_dump($filme);        
        $vetor = array($filme->getTitulo(),$filme->getClassif_ind(),$filme->getSinopse(),$filme->getDtlancamento(),
        $filme->getGenero(),$filme->getCategoria()->getId());
        $res = pg_query_params($conn,$sql, $vetor);
        $linha = pg_fetch_assoc($res);
        $filme->setId(intval($linha['id']));        
        foreach ($filme->getAtores() as $ator) {
           $sql2 = 'INSERT INTO atorfilme (idfilme, idator) VALUES ($1,$2)';
           $vetor2 = array($filme->getId(),$ator->getId());
           $res2 = pg_query_params($conn,$sql2, $vetor2);
           $linha2 = pg_fetch_assoc($res2); 
        }
        pg_close($conn);
    }   
    public function deletar($id)
    {
        $conn = $this->CriaConexao();
        $sql = 'DELETE FROM filme WHERE id= $1';
        $res = pg_query_params($conn, $sql,array($id));     
        pg_close($conn);        
        
    }
    public function buscar($id)
    {
        include_once('../classes/filme.php');
        include_once('../DAOs/categoria.php');
        include_once('../classes/ator.php');
        
        $conn = $this->CriaConexao();
        $sql = 'SELECT f.id as idf, titulo, af.idator,a.nome_artistico,classif_ind, a.nome as nomeator, sinopse, data_lancamento,genero,fk_categoria_id FROM filme f LEFT OUTER JOIN atorfilme af on f.id = af.idfilme
					LEFT OUTER join ator a on a.id = af.idator where f.id = $1';
        $res = pg_query_params($conn, $sql,array($id));     
        $res2 = pg_query_params($conn, $sql,array($id));    
        $linha = pg_fetch_assoc($res);
        $data= new DateTime($linha['data_lancamento']);                 
        $f = new filme($linha['titulo'],$linha['classif_ind'],$linha['sinopse'],$data->format('Y-m-d'),$linha['genero']);
        $f->setId(intval($linha['idf']));
        $categoriaDao = new CategoriaDAO();
        $c = $categoriaDao->buscar(intval($linha['fk_categoria_id']));
        $f->setCategoria($c);                                                    
        while($linha2 = pg_fetch_assoc($res2)){
            $ator= new Ator($linha2['nome_artistico']);
            $ator->setId(intval($linha2['idator']));
            $f->addAtor($ator);
        } 
        return $f;
    }
    public function listar($limit,$offset)
    {
        include_once('../classes/filme.php');    
        include_once('../DAOs/categoria.php');  
		$conn = $this->criaConexao();
        $sql = 'SELECT * FROM filme LIMIT $1 OFFSET $2';
        $res = pg_query_params($conn, $sql, array($limit, $offset));
        $listafilmes = array();
        while($linha = pg_fetch_assoc($res)){
            $data= new DateTime($linha['data_lancamento']);                 
			$f = new filme($linha['titulo'],$linha['classif_ind'],$linha['sinopse'],$data->format('Y-m-d'),$linha['genero']);
            $f->setId(intval($linha['id']));
            $categoriaDao = new CategoriaDAO();
            $c = $categoriaDao->buscar($linha['fk_categoria_id']);
            $f->setCategoria($c);
            array_push($listafilmes,$f);
            
        }        
		pg_close($conn);
		return ($listafilmes);
        
    }

    public function alterar($filme)
    {
        $conn = $this->criaConexao();
        $sql="UPDATE filme SET titulo = $1, classif_ind = $2, sinopse = $3, data_lancamento = $4, genero = $5, fk_categoria_id =$6 WHERE id = $7";
        $vet = array($filme->getTitulo(),$filme->getClassif_ind(),$filme->getSinopse(),$filme->getDtlancamento(),$filme->getGenero(),$filme->getCategoria()->getId(),$filme->getId());
		$res = pg_query_params($conn, $sql, $vet);
        
	}
 
}
?>
