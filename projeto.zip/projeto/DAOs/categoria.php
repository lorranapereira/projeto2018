<?php 

class CategoriaDAO {
    private function CriaConexao()
    {
        $scon = "port=5432 host=localhost dbname=bdfilmes
        user=postgres ";
        $con = pg_connect($scon);
        if(!$con){
        echo "conexão com BD falhou!";
        pg_close($con);
        }
        return $con;
    }
    public function inserir($categoria)
    {                
        $conn = $this->CriaConexao();
        $sql = 'INSERT INTO categoria (nome) VALUES ($1) RETURNING ID';
        $vetor = array($categoria->getNome());
        $res = pg_query_params($conn,$sql,$vetor);
        $linha = pg_fetch_assoc($res);
        $categoria->setId(intval($linha['id']));        
        pg_close($conn);
    }   
    public function deletar($id)
    {
        $conn = $this->CriaConexao();
        $sql = 'DELETE FROM categoria WHERE id= $1';
        $res = pg_query_params($conn, $sql,array($id));     
        pg_close($conn);        
        
    }
    public function buscar($id)
    {
        include_once('../classes/categoria.php');
        $conn = $this->CriaConexao();
        $sql = 'SELECT * FROM categoria where id=$1';
        $res = pg_query_params($conn, $sql,array($id));
        $linha = pg_fetch_assoc($res);
        $c = new Categoria($linha['nome']);
        $c->setId(intval($linha['id']));        
        pg_close($conn);
        return $c;
    }
    public function listar($limit,$offset)
    {
        include_once('../classes/categoria.php');                
		$conn = $this->criaConexao();
		$sql = 'SELECT * FROM categoria LIMIT $1 OFFSET $2';
		$res = pg_query_params($conn, $sql, array($limit, $offset));
		$listacategorias = array();
		while($linha = pg_fetch_assoc($res)){
			$c = new categoria($linha['nome']);
			$c->setId(intval($linha['id']));
			
			array_push($listacategorias,$c);
		}
		pg_close($conn);
		return $listacategorias;
        
    }

    public function alterar($categoria)
    {
        $conn = $this->criaConexao();
		$sql="UPDATE categoria SET nome = $1 WHERE id = $2 ";
		$vet = array($categoria->getNome(),$categoria->getId());
		$res = pg_query_params($conn, $sql, $vet);
		
	}
 
}
?>