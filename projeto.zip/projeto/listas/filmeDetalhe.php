<!DOCTYPE html>
<html lang="en">

  <head>

      <meta charset="utf-8">
      <meta http-equiv="X-UA-Compatible" content="IE=edge">
      <meta name="viewport" content="width=device-width, initial-scale=1, shrink-to-fit=no">
      <meta name="description" content="">
      <meta name="author" content="">
      <meta name="viewport" content="width=device-width, initial-scale=1">
      <title>SB Admin - Tables</title>
      <!-- Bootstrap core CSS-->
      <link href="../vendor/bootstrap/css/bootstrap.min.css" rel="stylesheet">
  
      <!-- Custom fonts for this template-->
      <link href="../vendor/fontawesome-free/css/all.min.css" rel="stylesheet" type="text/css">
  
      <!-- Page level plugin CSS-->
      <link href="../vendor/datatables/dataTables.bootstrap4.css" rel="stylesheet">
  
      <link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/bootstrap/3.3.7/css/bootstrap.min.css" integrity="sha384-BVYiiSIFeK1dGmJRAkycuHAHRg32OmUcww7on3RYdg4Va+PmSTsz/K68vbdEjh4u" crossorigin="anonymous">
      
  
    </head>
  
    <body id="page-top">
      <nav class="navbar navbar-expand navbar-dark bg-dark static-top">
          <a class="navbar-brand" href="../index.html">Logo</a>          
        <div class="collapse navbar-collapse" id="navbarNavDropdown">
        <ul class="navbar-nav">
          <li class="nav-item dropdown">
            <a class="nav-link dropdown-toggle active" href="#" id="navbarDropdownMenuLink" role="button" data-toggle="dropdown" aria-haspopup="true" aria-expanded="false">
              Cadastro
            </a>
            <div class="dropdown-menu" aria-labelledby="navbarDropdownMenuLink">
              <a class="dropdown-item active" href="filme.php">Filmes</a>
              <a class="dropdown-item" href="ator.php">Atores</a>
              <a class="dropdown-item" href="categoria.php">Categorias</a>
            </div>
          </li>
              <li class="nav-item dropdown">
                <a class="nav-link dropdown-toggle" href="#" id="navbarDropdownMenuLink" role="button" data-toggle="dropdown" aria-haspopup="true" aria-expanded="false">
                  Listas
                </a>
                <div class="dropdown-menu" aria-labelledby="navbarDropdownMenuLink">
                  <a class="dropdown-item" href="../listas/filmes.php">Filme</a>
                  <a class="dropdown-item" href="../listas/atores.php">Atores</a>
                  <a class="dropdown-item" href="../listas/categorias.php">Categorias</a>
                </div>
              </li>
        </ul>
        </div>
  
      </nav>
      <br/>
      <div class="container">
      <h1> Filmes </h1>
      <br/> 
      <?php
          include_once('../DAOs/filme.php');
          include_once('../DAOs/categoria.php');                    
          $filmedao = new FilmeDAO();
          $f = $filmedao->buscar(intval($_GET['id']));  
          $data = new Datetime($f->getDtlancamento());                    
        ?>
        <div class="card" style="width: 108rem;">
        <ul class="list-group list-group-flush">
        
            <li class="list-group-item"><h4><strong>Título: </strong><?php echo $f->getTitulo(); ?><h4></li>
            <li class="list-group-item"><h4><strong>Sinopse: </strong><?php echo $f->getSinopse(); ?></h4></li>
            <li class="list-group-item"><h4><strong>Classificação indicativa: </strong><?php echo $f->getClassif_ind(); ?></h4></li>
            <li class="list-group-item"><h4><strong>Gênero: </strong><?php echo $f->getGenero(); ?></h4></li>
            <li class="list-group-item"><h4><strong>Categoria: </strong><?php echo $f->getCategoria()->getNome(); ?></h4></li>
            <li class="list-group-item"><h4><strong>Data de lançamento: </strong><?php echo $data->format('d-m-Y'); ?></h4></li>
            </ul>
            <div class="panel-heading"><h4><strong>Atores</h4></div>

            <?php 
             $i=0;
             foreach ($f->getAtores() as $a) {
             $i = $i+1;
            ?>
            <li class="list-group-item"><h4><?php echo $a->getNome(); ?></h4></li>
            <?php 
            }
            ?>
        </div>
      </div>
      <footer class="sticky-footer" style="width:100%;">
          <div class="container my-auto">
              <div class="copyright text-center my-auto" style="font-size:13px;">
                  <span>Sistema Administrador © Site de filmes 2018</span>
              </div>
              </div>
      </footer>    
  
      <!-- /.content-wrapper -->

    <!-- /#wrapper -->

    <!-- Scroll to Top Button-->
    
    <script src="../vendor/jquery/jquery.min.js"></script>
    <script src="../vendor/bootstrap/js/bootstrap.bundle.min.js"></script>

    <!-- Core plugin JavaScript-->
    <script src="../vendor/jquery-easing/jquery.easing.min.js"></script>



  </body>

</html>
