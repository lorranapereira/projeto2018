<?php include_once('../html/cabecalho.html');?>
  <body id="page-top">

    <nav class="navbar navbar-expand navbar-dark bg-dark static-top">
      <a class="navbar-brand" href="../index.html">Logo</a>
      <div class="collapse navbar-collapse" id="navbarNavDropdown">
      <ul class="navbar-nav">
        <li class="nav-item dropdown">
          <a class="nav-link dropdown-toggle" href="#" id="navbarDropdownMenuLink" role="button" data-toggle="dropdown" aria-haspopup="true" aria-expanded="false">
            Cadastro
          </a>
          <div class="dropdown-menu" aria-labelledby="navbarDropdownMenuLink">
            <a class="dropdown-item" href="../cadastros/filme.php">Filme</a>
            <a class="dropdown-item" href="../cadastros/ator.php">Atores</a>
            <a class="dropdown-item" href="../cadastros/categoria.php">Categorias</a>
          </div>
        </li>
            <li class="nav-item dropdown">
              <a class="nav-link dropdown-toggle active" href="#" id="navbarDropdownMenuLink" role="button" data-toggle="dropdown" aria-haspopup="true" aria-expanded="false">
                Listas
              </a>
              <div class="dropdown-menu" aria-labelledby="navbarDropdownMenuLink">
                <a class="dropdown-item" href="filmes.php">Filmes</a>
                <a class="dropdown-item active" href="atores.php">Atores</a>
                <a class="dropdown-item" href="categorias.php">Categorias</a>
              </div>
            </li>
      </ul>
      </div>
    </nav>
    
    <br/>
    <div class="container">
      <div id="content-wrapper">

        <div class="container-fluid">

          <!-- Breadcrumbs-->
          <ol class="breadcrumb">
            <li class="breadcrumb-item active">
              Tabelas
            </li>
            <li class="breadcrumb-item">Atores</li>
          </ol>

          <!-- DataTables Example -->
          <div class="card mb-3">
            <div class="card-header">
              <i class="fas fa-table"></i>
              Tabela Atores
              <a href="../cadastros/ator.php" class="btn btn-primary" style="position: relative; color:white; left:80%;"> Adicionar</a> 
              
            </div>
            <div class="card-body">
              <div class="table-responsive">
                <table class="table table-bordered" id="dataTable" width="100%" cellspacing="0">
                  <thead>
                    <tr>
                      <th>Código</th>
                      <th>Nome Artístico</th>
                      <th>Nome</th>
                      <th>Data Nascimento</th>
                      <th>Editar</th>
                      <th>Excluir</th>                        
                    </tr>
                  </thead>
                  <tbody>
                    <?php
                    include_once('../DAOs/ator.php');
                    $a = new AtorDAO();
                    $atores = $a->listar(200,0);  
                    $i = 0;  
                    foreach ($atores as $v) {
                      $data = new Datetime($v->getDtnascimento());
                    ?>
                    <tr>
                      <th scope="row"><?php echo ($v->getId()); ?></th>
                      <td><?php echo ($v->getNome_artistico()); ?></td>
                      <td><?php echo ($v->getNome()); ?></td>
                      <td><?php echo $data->format('d-m-Y'); ?></td>
                      <td><a href="../cadastros/ator.php?id=<?php echo $v->getId() ?>"><span class="glyphicon glyphicon-pencil"></span></a>                        
                      </td>
                      <td><a href="deletar/deletarAtor.php?id=<?php echo $v->getId() ?>"><span class="glyphicon glyphicon-remove"></span></a>
                      </td>
                    </tr>
                  </tbody>
                <?php }?>
                </table>
              </div>
            </div>
          </div>
        </div>
      </div>
    </div>
<?php include_once('../html/footer.html');?>
        