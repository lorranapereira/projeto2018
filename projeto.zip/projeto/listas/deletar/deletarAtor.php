<?php

    include_once('../../DAOs/ator.php');
    $adao = new AtorDAO();
    $id = intval($_GET['id']);
    $adao->deletar($id);
    header('Location:../atores.php');

?>