<?php

    include_once('../../DAOs/filme.php');
    $fdao = new FilmeDAO();
    $id = intval($_GET['id']);
    $fdao->deletar($id);
    header('Location:../filmes.php');

?>