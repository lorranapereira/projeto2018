<!DOCTYPE html>
<html lang="en">

  <head>

      <meta charset="utf-8">
      <meta http-equiv="X-UA-Compatible" content="IE=edge">
      <meta name="viewport" content="width=device-width, initial-scale=1, shrink-to-fit=no">
      <meta name="description" content="">
      <meta name="author" content="">
      <meta name="viewport" content="width=device-width, initial-scale=1">
      <title>SB Admin - Cadastro</title>
      <!-- Bootstrap core CSS-->
      <link href="../vendor/bootstrap/css/bootstrap.min.css" rel="stylesheet">
  
      <!-- Custom fonts for this template-->
      <link href="../vendor/fontawesome-free/css/all.min.css" rel="stylesheet" type="text/css">
  
      <!-- Page level plugin CSS-->
      <link href="../vendor/datatables/dataTables.bootstrap4.css" rel="stylesheet">
  
      <link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/bootstrap/3.3.7/css/bootstrap.min.css" integrity="sha384-BVYiiSIFeK1dGmJRAkycuHAHRg32OmUcww7on3RYdg4Va+PmSTsz/K68vbdEjh4u" crossorigin="anonymous">
      
  
    </head>
  
    <body id="page-top">
      <nav class="navbar navbar-expand navbar-dark bg-dark static-top">
          <a class="navbar-brand" href="../index.html">Logo</a>          
        <div class="collapse navbar-collapse" id="navbarNavDropdown">
        <ul class="navbar-nav">
          <li class="nav-item dropdown">
            <a class="nav-link dropdown-toggle active" href="#" id="navbarDropdownMenuLink" role="button" data-toggle="dropdown" aria-haspopup="true" aria-expanded="false">
              Cadastro
            </a>
            <div class="dropdown-menu" aria-labelledby="navbarDropdownMenuLink">
              <a class="dropdown-item active" href="filme.php">Filme</a>
              <a class="dropdown-item" href="ator.php">Ator</a>
              <a class="dropdown-item" href="categoria.php">Categoria</a>
            </div>
          </li>
              <li class="nav-item dropdown">
                <a class="nav-link dropdown-toggle" href="#" id="navbarDropdownMenuLink" role="button" data-toggle="dropdown" aria-haspopup="true" aria-expanded="false">
                  Listas
                </a>
                <div class="dropdown-menu" aria-labelledby="navbarDropdownMenuLink">
                  <a class="dropdown-item" href="../listas/filmes.php">Filmes</a>
                  <a class="dropdown-item" href="../listas/atores.php">Atores</a>
                  <a class="dropdown-item" href="../listas/categorias.php">Categorias</a>
                </div>
              </li>
        </ul>
        </div>
  
      </nav>
      <br/>
      <div class="container">
        <div id="content-wrapper">
  
          <div class="container-fluid">
  
            <?php 
              if($_GET["id"]){
                  include_once("../DAOs/filme.php");
                  include_once("../classes/filme.php");
                  $filmeDao = new FilmeDAO();
                  $f = $filmeDao->buscar(intval($_GET["id"]));
                }

            ?> 
            <ol class="breadcrumb">
            <h1> <?php if($_GET["id"]){ echo " Alterar"; } else {echo "Cadastrar ";}?>  Filme</h1>
            </ol>  
            <form id="form" action="inserir/filme.php" method="POST">
                <div class="form-row">
                  <div class="form-group col-md-6">
                    <label for="inputtext4">Título</label>
                    <input type="text" name="titulo" value="<?php if($_GET["id"]){ echo $f->getTitulo(); } ?>" class="form-control" id="inputtext4" >
                  </div>
                  <div class="form-group">
                      <label for="exampleFormControlSelect1">Classificação indicativa</label>
                      <select name="classif_ind" value="<?php if($_GET["id"]) echo $f->getClassif_ind()?>" class="form-control" id="exampleFormControlSelect1">
                        <option value="L">L</option>
                        <option value="10">10</option>
                        <option value="12">12</option>
                        <option value="14">14</option>
                        <option value="16">16</option>
                        <option value="18">18</option>
                      </select>
                    </div>
                  </div>
                <div class="form-group">
                    <label for="exampleFormControlTextarea1">Sinopse</label>
                    <textarea name="sinopse" value="<?php if($_GET["id"]){ echo $f->getSinopse(); }?>" class="form-control" rows="3"><?php if($_GET["id"]){ echo $f->getSinopse(); }?></textarea>
                </div>
                <div class="form-group">
                    <label for="inputZip">Lançamento</label>
                    <input name="lancamento" value="<?php if($_GET["id"]){ echo $f->getDtlancamento(); }?>" type="date" class="form-control">
                </div>
                <div class="form-group">
                    <label for="inputZip">Gênero</label>
                    <input name="genero" value="<?php if($_GET["id"]){ echo $f->getGenero(); }?>" type="text" class="form-control">
                </div>
                <input name="id" value="<?php if($_GET['id']){  echo $f->getId();}?>" type="hidden"> 

                <div id= "cate" class="form-group">
                    <label for="inputZip">Categoria</label>
                    <select name="categoria" value="<?php if($_GET["id"]){ echo $f->getCategoria()->getNome(); }?>"  class="form-control form-control">
                      <?php
                        include_once('../DAOs/categoria.php');
                        $c = new CategoriaDAO();
                        $categorias = $c->listar(500,0);  
                        $i = 0;  
                        foreach ($categorias as $v) {
                      ?>
                      <option  value="<?php if($_GET['id']){  echo $v->getId();} else { echo $v->getId(); } ?>" ><?php echo $v->getNome(); ?></option>
                    <?php }; ?> 
                    </select> 
                    <br/>       

                  </div>
                  <?php if(isset($_GET['id']) == false){ ?>
                  <label for="inputZip">Ator </label>
                  <div class="form-group" >
                      <select name="ddd" class="form-control" id="exampleFormControlSelect1">
                      <?php
                        include_once('../DAOs/ator.php');
                        $a = new AtorDAO();
                        $atores = $a->listar(500,0);  
                        $i = 0;  
                        foreach ($atores as $v) {
                      ?>
                          <option value="<?php if($_GET['id']){  echo $v->getNome_artistico();} else { echo $v->getNome_artistico(); } ?>" > <?php echo $v->getNome_artistico(); ?></option>
                      <?php } ?>
                      </select>    
                      <br/>    
                      <div id="novoinput"></div>              
                          <span class="glyphicon glyphicon-plus-sign"></span>
                      <button type="button" id="add" class="btn btn-danger" >
                          Ator
                      </button> 
            
                      <script>

                        ctd=0;
                        vetorId=[];
                        vetorValue=[];
                        document.getElementById("add").addEventListener("click", function(){
                          if (vetorId.length > 0) {
                            var Select = document.createElement('select');
                            Select.name = "ator"+ctd;

                          }
                          <?php
                            include_once('../DAOs/ator.php');
                            $a = new AtorDAO();
                            $atores = $a->listar(500,0);  
                            $i = 0;  
                            foreach ($atores as $v) {
                            
                          ?>  
                          if(ctd == 0){ 

                            var Select = document.createElement('select');           
                            vetorId.push("<?php echo $v->getId(); ?>");
                            vetorValue.push("<?php echo $v->getNome_artistico(); ?>");  
                          } 
                          <?php }  ?>
                          if(ctd >= 1 && vetorId.length > 0 ){
                            aux = ctd-1;
                            var selectAnterior = document.getElementById(aux);
                            var selectValue = selectAnterior.options[document.getElementById(aux).selectedIndex].text;
                            var selectId = selectAnterior.options[document.getElementById(aux).selectedIndex].value;
                            selectAnterior.setAttribute("selected",selectId);
                            var posId = vetorId.indexOf(selectId);
                            var posValue = vetorValue.indexOf(selectValue);
                            vetorId.splice(posId, 1);
                            vetorValue.splice(posValue, 1);

                          }
                          for (var i = 0; i < vetorId.length; i++) {

                            var option = document.createElement("option");
                            option.value = vetorId[i]; 
                            option.text = vetorValue[i];
                            Select.appendChild(option);
                            Select.id = ctd;
                            Select.className = "form-control form-control";
                            Select.readOnly = true;
                          }
                          if (i == vetorId.length && i!=0 ) {
                            var label = document.createElement("LABEL");
                            label.textContent = "Ator";
                            var br = document.createElement("br");
                            document.querySelector("form").appendChild(label);
                            document.querySelector("form").appendChild(Select);
                            document.querySelector("form").appendChild(br);

                            ctd++;
                          }
                          document.getElementById("limpar").addEventListener("click", function(){
                            ctd = 0;
                            vetorId=[];
                            vetorValue=[];

                          });


                        });

                      </script>
                    <?php } ?>
                    <button type="submit" class="btn btn-primary">Enviar</button>
                  </div>
               </div>
          </div>
        </div>
      </form>
      <footer class="sticky-footer" style="width:100%;">
          <div class="container my-auto">
              <div class="copyright text-center my-auto" style="font-size:13px;">
                <span>Sistema Administrador © Site de filmes 2018</span>
              </div>
            </div>
      </footer>    
  
      <!-- /.content-wrapper -->

    <!-- /#wrapper -->

    <!-- Scroll to Top Button-->
    
    <script src="../vendor/jquery/jquery.min.js"></script>
    <script src="../vendor/bootstrap/js/bootstrap.bundle.min.js"></script>

    <!-- Core plugin JavaScript-->
    <script src="../vendor/jquery-easing/jquery.easing.min.js"></script>



  </body>

</html>
