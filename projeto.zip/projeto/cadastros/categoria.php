<!DOCTYPE html>
<html lang="en">

  <head>
  <meta charset="utf-8">
  <meta http-equiv="X-UA-Compatible" content="IE=edge">
  <meta name="viewport" content="width=device-width, initial-scale=1, shrink-to-fit=no">
  <meta name="description" content="">
  <meta name="author" content="">
  <meta name="viewport" content="width=device-width, initial-scale=1">
  <title>SB Admin - Tables</title>
  <!-- Bootstrap core CSS-->
  <link href="vendor/bootstrap/css/bootstrap.min.css" rel="stylesheet">

  <!-- Bootstrap core CSS-->
  <link href="../vendor/bootstrap/css/bootstrap.min.css" rel="stylesheet">

  <!-- Custom fonts for this template-->
  <link href="../vendor/fontawesome-free/css/all.min.css" rel="stylesheet" type="text/css">

  <!-- Page level plugin CSS-->
  <link href="../vendor/datatables/dataTables.bootstrap4.css" rel="stylesheet">

  <!-- Custom styles for this template-->   
  <link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/bootstrap/3.3.7/css/bootstrap.min.css" integrity="sha384-BVYiiSIFeK1dGmJRAkycuHAHRg32OmUcww7on3RYdg4Va+PmSTsz/K68vbdEjh4u" crossorigin="anonymous">



  </head>

  <body id="page-top">
  <nav class="navbar navbar-expand navbar-dark bg-dark static-top">
      <a class="navbar-brand" href="../index.html">Logo</a>
      
    <div class="collapse navbar-collapse" id="navbarNavDropdown">
    <ul class="navbar-nav">
      <li class="nav-item dropdown">
        <a class="nav-link dropdown-toggle active" href="#" id="navbarDropdownMenuLink" role="button" data-toggle="dropdown" aria-haspopup="true" aria-expanded="false">
          Cadastro
        </a>
        <div class="dropdown-menu" aria-labelledby="navbarDropdownMenuLink">
          <a class="dropdown-item" href="filme.php">Filme</a>
          <a class="dropdown-item" href="ator.php">Ator</a>
          <a class="dropdown-item active" href="categoria.php">Categoria</a>
        </div>
      </li>
          <li class="nav-item dropdown">
            <a class="nav-link dropdown-toggle" href="#" id="navbarDropdownMenuLink" role="button" data-toggle="dropdown" aria-haspopup="true" aria-expanded="false">
              Listas
            </a>
            <div class="dropdown-menu" aria-labelledby="navbarDropdownMenuLink">
              <a class="dropdown-item" href="../listas/filmes.php">Filmes</a>
              <a class="dropdown-item" href="../listas/atores.php">Atores</a>
              <a class="dropdown-item" href="../listas/categorias.php">Categorias</a>
            </div>
          </li>
    </ul>
    </div>

  </nav>
  <br/>
  <div class="container">
    <div id="content-wrapper">

      <div class="container-fluid">

        <!-- Breadcrumbs-->
        <ol class="breadcrumb">    
        <?php 
              if($_GET["id"]){
                  include_once("../DAOs/categoria.php");
                  include_once("../classes/categoria.php");
                  $categoriaDAO = new categoriaDAO();
                  $c = $categoriaDAO->buscar(intval($_GET["id"]));
                }

            ?>
            <h1> <?php if($_GET["id"]){ echo "Alterar "; } else { echo "Cadastrar ";}?>Categoria</h1>
        </ol>  
          <form action="inserir/categoria.php" method="post">
              <div class="form-row">
                <div class="form-group col-md-6">
                  <label for="inputtext4">Nome</label>
                  <input type="text" value="<?php if($_GET["id"]){ echo $c->getNome();} ?>" name="nome" class="form-control" id="inputtext4" >
                  <input type="hidden" name="id" value="<?php if($_GET["id"]){ echo $c->getId();} ?>" class="form-control" id="inputtext4" >

                </div>
              </div>                
                <br/>
                <button type="submit" class="btn btn-primary">Enviar</button>
          </form>
        </div>
        <footer class="sticky-footer" style="position:relative; top:18em; width:100%;">
            <div class="container my-auto">
                <div class="copyright text-center my-auto" style="font-size:13px;">
                  <span>Sistema Administrador © Site de filmes 2018</span>
                </div>
              </div>
        </footer>    
    
        <!-- /.content-wrapper -->

      <!-- /#wrapper -->

      <!-- Scroll to Top Button-->
      
      <!-- Bootstrap core JavaScript-->
    <!-- Bootstrap core JavaScript-->
    <script src="../vendor/jquery/jquery.min.js"></script>
    <script src="../vendor/bootstrap/js/bootstrap.bundle.min.js"></script>

    <!-- Core plugin JavaScript-->
    <script src="../vendor/jquery-easing/jquery.easing.min.js"></script>

    <!-- Page level plugin JavaScript-->
    <script src="../vendor/chart.js/Chart.min.js"></script>


    </body>

</html>
