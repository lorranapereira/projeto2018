<?php

include_once('../../classes/categoria.php');
include_once('../../DAOs/categoria.php');

$c = new Categoria($_POST["nome"]);
$cdao = new CategoriaDAO();

if($_POST['id']){
    $c->setId(intval($_POST['id']));
    $cdao->alterar($c);
}else{
    $cdao->inserir($c);    
}
header('Location:../../listas/categorias.php');

?>