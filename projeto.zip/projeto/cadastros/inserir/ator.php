<?php

include_once('../../classes/ator.php');
include_once('../../DAOs/ator.php');
$data = new DateTime($_POST['dtnascimento']);
$a = new Ator($_POST['nome'],$_POST['nome_artistico'],$data->format('Y-m-d'));
$adao = new AtorDAO();
if($_POST['id']){
    $a->setId(intval($_POST['id']));
    var_dump($a);
    $adao->alterar($a);
}else{
    $adao->inserir($a);
}
header('Location:../../listas/atores.php');
?>