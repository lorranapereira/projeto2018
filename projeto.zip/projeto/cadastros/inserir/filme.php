<?php

include_once('../../classes/categoria.php');
include_once('../../classes/ator.php');
include_once('../../classes/filme.php');
include_once('../../DAOs/filme.php');
include_once('../../DAOs/categoria.php');
include_once('../../DAOs/ator.php');


$i = 1;
$filmeDAO = new FilmeDAO();
$data = new DateTime($_POST['lancamento']);
$f = new Filme($_POST["titulo"],$_POST["classif_ind"],$_POST["sinopse"],$data->format('Y-m-d'),$_POST["genero"]);
$categoriaDao = new CategoriaDAO();
$c = $categoriaDao->buscar(intval($_POST["categoria"]));
$f->setCategoria($c);
if($_POST['id']){
    $f->setId(intval($_POST['id']));
    $filmeDAO->alterar($f);
}else{
    while (isset($_POST['ator'.$i])){
        $a = new AtorDAO();
        $ator = $a->buscar(intval($_POST['ator'.$i]));
        $f->addAtor($ator);
        $i++;    
    }
    $filmeDAO->inserir($f);
}
header('Location:../../listas/filmes.php');

?>
