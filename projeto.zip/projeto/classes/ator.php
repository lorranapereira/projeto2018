<?php
class Ator{
    private $id;
    private $nome;
    private $nome_artistico;
    private $dtnascimento;
   
    public function __construct($nome=null, $nome_artistico=null,$dtnascimento=null){
        $this->nome = $nome;
        $this->nome_artistico = $nome_artistico;
        $this->dtnascimento = $dtnascimento;        
    }
    public function getId(){
        return $this->id;
    }
    public function getNome(){
        return $this->nome;
    }
    public function getNome_artistico(){
        return $this->nome_artistico;
    }
    public function getDtnascimento(){
		return $this->dtnascimento;
    }
    public function setId(int $id){
        $this->id = $id;
    }
    public function setNome(String $nome){
        $this->nome = $nome;
    }
    public function setNome_artistico(String $nome_artistico){
        $this->nome_artistico = $nome_artistico;
    }
    public function setDtnascimento(Date $dtnascimento){
        $this->dtnascimento = $dtnascimento;
    }
}
?>
