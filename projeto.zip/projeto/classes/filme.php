<?php

class Filme{
    private $id;
    private $titulo;
    private $classif_ind;    
    private $sinopse;
    private $dtlancamento;    
    private $genero;
    private $categoria;
    private $atores;
    public function __construct($titulo,$classif_ind,$sinopse=null, $dtlancamento=null, $genero=null){
        $this->titulo = $titulo;
        $this->classif_ind = $classif_ind;        
        $this->sinopse = $sinopse;
        $this->dtlancamento = $dtlancamento;
        $this->genero = $genero;                
        $this->atores = array();
    }
    public function addAtor(Ator $a) {
        array_push($this->atores,$a);
    }
    public function getAtores(){
        return $this->atores;
    }
    public function getId(){
        return $this->id;
    }
    public function getTitulo(){
        return $this->titulo;
    }
    public function getSinopse(){
        return $this->sinopse;
    }
    public function getClassif_ind(){
        return $this->classif_ind;
    }
	public function getCategoria(){        
		return $this->categoria;
    }
    public function getGenero(){
		return $this->genero;
    }
    public function getDtlancamento(){
		return $this->dtlancamento;
    }
    public function setId(int $id){
        $this->id = $id;
    }
    public function setTitulo(String $titulo){
        $this->titulo = $titulo;
    }
    public function setSinopse(String $sinopse){
        $this->sinopse = $sinopse;
    }
    public function setClassif_ind(String $classif_ind){
        if($classif_ind = 'L' OR $classif_ind = '10' OR $classif_ind = '12' OR $classif_ind = '14' OR $classif_ind = '16' OR $classif_ind = '18')
        $this->classif_ind = $classif_ind;
    }
    public function setGenero(String $genero){
            $this->genero = $genero;
    }
    public function setCategoria( Categoria $categoria){
        $this->categoria = $categoria;
    }
    public function setDtlacamento($dtlancamento){
        $this->dtlancamento = $dtlancamento;
    }
}
?>
